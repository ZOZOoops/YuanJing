import unittest

from Yuanjing_ui.Base.base_page import Keys


class PageObject(unittest.TestCase,Keys):

    def setUp(self) -> None:
        pass
    def tearDown(self) -> None:
        pass

    def test_001_nologin_view(self):
        pass

