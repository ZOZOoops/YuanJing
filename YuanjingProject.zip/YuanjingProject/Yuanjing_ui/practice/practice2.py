from Yuanjing_ui.Base.base_page import Keys

class practice(Keys):

    def test(self):

        self.open('https://www.yuanjingio.com')

a = practice()
a.test()

